# DDoS
This is a Ip ddoser made by aligamm [ education purpose ]
please dont ddos any random websites or ips 


Leave a star if u like my skid tool 
sadly my tool dont work on linux
